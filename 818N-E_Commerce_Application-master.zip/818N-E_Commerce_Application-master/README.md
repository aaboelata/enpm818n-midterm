# E-Commerce-PHP-MySQL-
<p align="center"><img src="./ui/Ecommerce-Home-Page.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Products.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Cart-Details-Page.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Login.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Registration.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Dashboard.png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Dashboard (1).png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Dashboard (2).png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Dashboard (3).png" width="100%" alt="View"></p>
<p align="center"><img src="./ui/Ecommerce-Admin-Dashboard (4).png" width="100%" alt="View"></p>
